<?php
ob_start();
session_start();
include 'connect.php';
if($_SESSION['login']=="1"||$_SESSION['login']=="4")
{
?>
<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"/>
<title>Update Panel</title>
<script type="text/javascript">
function validate()
{
var x=document.forms["updatename"]["custname"].value;
//document.write(x);
if(x==null||x=="")
{alert("Customer name cannot blank!");
return false;
}
else
{
return true;
}
}
function validate1()
{
var y=document.forms["updatephone"]["phone"].value;
if(y==null||y=="")
{alert("Phone number cannot be blank!");
return false;
}
else if(!y.match(/^\d+/))
{alert("Only numeric characters allowed for phone no");
return false;
}
else if (y.length>10||y.length<10)
{
alert("Phone no should contain 10 digits");
return false;
}
else
{
return true;
}
}
function validate2()
{
var z=document.forms["updateemail"]["email"].value;
var atpos=z.indexOf("@");
var dotpos=z.lastIndexOf(".");
if(z==null||z=="")
{alert("Email cannot be blank!");
return false;
}
else if(atpos<1||dotpos<atpos+2||dotpos+2>=z.length)
{
alert("Not a valid email address");
return false;
}
else
{
return true;
}
}
</script>

</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Sales Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="manage.php"><font color="black" size="5">Customer Records</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<?php
$code=$_GET['code'];
$submit=$_GET['sub'];
if($submit=='name')
{
echo '
<form action="change.php" method="get" name="updatename" onSubmit="return validate();">
 <h3>Update Existing Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Name :</font></td>
<td><input type="text" name="custname" maxlength="30"/>
</td>
</tr>
<input type="hidden" name="code" value="'.$code.'">
<tr>
<td colspan="2" align="center">
<input type="submit" value="Update_Name" name="sub">
</td>
</tr>
</table>
 </form>';
}
else if($submit=='Update_Name')
{
$code=$_GET['code'];
$custname=$_GET['custname'];
mysqli_query($con,"update customer set cust_name='$custname' where cust_id='$code'");
header("location:manage.php");
}
else if($submit=='address')
{
echo '
<form action="change.php" method="get">
 <h3>Update Existing Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Address :</font></td>
<td><input type="text" name="address"/>
</td>
</tr>
<input type="hidden" name="code" value="'.$code.'">
<tr>
<td colspan="2" align="center">
<input type="submit" value="Update_Address" name="sub">
</td>
</tr>
</table>
 </form>';
}
else if($submit=='Update_Address')
{
$code=$_GET['code'];
$address=$_GET['address'];
mysqli_query($con,"update customer set address='$address' where cust_id='$code'");
header("location:manage.php");
}
else if($submit=='phone')
{
echo '
<form action="change.php" method="get" name="updatephone" onSubmit="return validate1();">
 <h3>Update Existing Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Phone :</font></td>
<td><input type="text" name="phone"/>
</td>
</tr>
<input type="hidden" name="code" value="'.$code.'">
<tr>
<td colspan="2" align="center">
<input type="submit" value="Update_Phone" name="sub">
</td>
</tr>
</table>
 </form>';
}
else if($submit=='Update_Phone')
{
$code=$_GET['code'];
$phone=$_GET['phone'];
mysqli_query($con,"update customer set phone=$phone where cust_id='$code'");
header("location:manage.php");
}
else if($submit=='email')
{
echo '
<form action="change.php" method="get" name="updateemail" onSubmit="return validate2();">
 <h3>Update Existing Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Email :</font></td>
<td><input type="text" name="email"/>
</td>
</tr>
<input type="hidden" name="code" value="'.$code.'">
<tr>
<td colspan="2" align="center">
<input type="submit" value="Update_Email" name="sub">
</td>
</tr>
</table>
 </form>';
}
else if($submit=='Update_Email')
{
$code=$_GET['code'];
$email=$_GET['email'];
mysqli_query($con,"update customer set email='$email' where cust_id='$code'");
header("location:manage.php");
}
else if($submit=='delete')
{
$code=$_GET['code'];
mysqli_query($con,"delete from customer where cust_id='$code'");
header("location:manage.php");
}
}
else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>