<?php
ob_start();
session_start();
if($_SESSION['login']=="4"||$_SESSION['login']=="1")
{
?>
<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"/>
<title>Sales Panel</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Sales Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<?php 
include 'connect.php';
$submit=$_POST['sub'];
if($submit=='Register')
{
$custname=$_POST['custname'];
$address=$_POST['address'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$code=uniqid();
$c=substr($code,-4);
mysqli_query($con,"insert into customer(cust_name,cust_id,address,phone,email) values('$custname','$c','$address',$phone,'$email')");

$result=mysqli_query($con,'select * from stock');
echo '<form action="saleconfirm.php" method="post" name="sale">
 <h3>Register Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Code:</font></td>
<td><input type="text" name="code" value="'.$c.'" readonly="readonly" />
</td>
</tr>
 

<tr>
<td><font face="calibri">Customer Name :</font></td>
<td><input type="text" name="custname" value="'.$custname.'" readonly="readonly" />
</td>
</tr>
 
<tr>
<td><font face="calibri">Quantity of :</font><select name="proname">';
while($row=mysqli_fetch_array($result))
{
echo
'<option value="'.$row[1].'">'.$row[1].'</option>';
}
echo '</select></td>
<td><input type="text" name="qty"/><font face="calibri">
(in numeric)
</td>
</tr>

<tr>
<td><font face="calibri">Sale Date :</font></td>
 
<td>
<select name="day">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select name="month">
<option value="-1">Month:</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
 
<select name="year">
 
<option value="-1">Year:</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
</select>
</td>
</tr>
 
<tr>
<td colspan="2" align="center">
<input type="submit" value="Sell" name="sub">
</td>
</tr>
</table>
 
</form>';


}
else if($submit=='Search')
{
$cid=$_POST['cid'];
$flag=0;
$res1=mysqli_query($con,'select * from customer');
while($row1=mysqli_fetch_array($res1))
{
if($row1[2]==$cid)
{
$flag=1;
$custname=$row1[1];
}
}
if($flag==0)
{?>
<script type="text/javascript">
alert("Invalid Customer Code!");
location="sale.php";
  </script><?php
}
else
{
$result=mysqli_query($con,'select * from stock');
echo '<form action="saleconfirm.php" method="post" name="sale">
 <h3>Register Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Code:</font></td>
<td><input type="text" name="code" value="'.$cid.'" readonly="readonly" />
</td>
</tr>
 

<tr>
<td><font face="calibri">Customer Name :</font></td>
<td><input type="text" name="custname" value="'.$custname.'" readonly="readonly" />
</td>
</tr>
 
<tr>
<td><font face="calibri">Quantity of :</font><select name="proname">';
while($row=mysqli_fetch_array($result))
{
echo
'<option value="'.$row[1].'">'.$row[1].'</option>';
}
echo '</select></td>
<td><input type="text" name="qty"/><font face="calibri">
(in numeric)
</td>
</tr>

<tr>
<td><font face="calibri">Sale Date :</font></td>
 
<td>
<select name="day">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select name="month">
<option value="-1">Month:</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
 
<select name="year">
 
<option value="-1">Year:</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
</select>
</td>
</tr>
 
<tr>
<td colspan="2" align="center">
<input type="submit" value="Sell" name="sub">
</td>
</tr>
</table>
 
</form>';



}


}

}
 else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
 ?>
</body>
</html>