<?php
ob_start();
session_start();
if($_SESSION['login']=="2"||$_SESSION['login']=="1")
{
?>
<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"/>
<title>Purchasers Panel</title>
<script type="text/javascript">
function validate()
{
var x=document.forms["purchase"]["proname"].value;
//document.write(x);
var y=document.forms["purchase"]["quantity"].value;
var z=document.forms["purchase"]["price"].value;
if(x==null||x=="")
{alert("Product name cannot blank!");
return false;
}
else if(y==null||y=="")
{alert("Quantity cannot be blank!");
return false;
}
else if(!y.match(/^\d+/))
{alert("Only numeric characters allowed for quantity!");
return false;
}
else if(z==null||z=="")
{alert("Price cannot be blank!");
return false;
}
else if(!z.match(/^\d+/))
{alert("Only numeric characters allowed for price!");
return false;
}
else
{
return true;
}
}
</script>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Purchasers Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<?php 
include 'connect.php';
if(!isset($_GET['sub']))
{
echo '<br><table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
<tr>
<td><font face="calibri">1:</font></td>
<td><a href="purchase.php?sub=addnew">Add New Product</a></td>
<td><img src="photos/new.png" width="50"></td>
</tr>
 

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="purchase.php?sub=purpro">Product Purchase</a></td>
<td><img src="photos/prod.jpg" width="50"></td>
</tr>
 </table>';
 
 }
 else
 {
 $submit=$_GET['sub'];
 if($submit=='addnew')
 {
echo '<form action="purchaseconfirm.php" method="post" name="purchase" onSubmit="return validate();">
 <h3>Add New Product</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Product Name :</font></td>
<td><input type="text" name="proname" maxlength="30"/><font face="calibri">
(maximum 30 characters)</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Quantity :</font></td>
<td><input type="text" name="quantity"/><font face="calibri">
(in numeric)</font>
</td>
</tr>
 
<tr>
<td><font face="calibri">Price :</font></td>
<td><input type="text" name="price"/><font face="calibri">
(in numeric)
</td>
</tr>

<tr>
<td><font face="calibri">Purchase Date :</font></td>
 
<td>
<select name="day">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select name="month">
<option value="-1">Month:</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
 
<select name="year">
 
<option value="-1">Year:</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
</select>
</td>
</tr>
 
<tr>
<td colspan="2" align="center">
<input type="submit" value="Add_Product" name="sub">
</td>
</tr>
</table>
 
</form>';
}
else
{
$result=mysqli_query($con,'select * from stock');
$result1=mysqli_query($con,'select * from stock');
//while($row=mysqli_fetch_array($result))

echo '<form action="purchaseconfirm.php" method="post" name="purchase" onSubmit="return validate();">
 <h3>Product Purchase</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Product Name :</font></td>
<td><select name="proname">';
while($row=mysqli_fetch_array($result))
{
echo
'<option value="'.$row[1].'">'.$row[1].'</option>';
}
echo '</select></td>
</tr>
 

<tr>
<td><font face="calibri">Quantity :</font></td>
<td><input type="text" name="quantity"/><font face="calibri">
(in numeric)</font>
</td>
</tr>
 
<tr>
<td>

<font face="calibri">Price :</font></td>
<td>
<select name="price">';
while($row1=mysqli_fetch_array($result1))
{echo
'<option value="'.$row1[3].'">'.$row1[1].' @ Rs.'.$row1[3].'/-</option>';
}
echo '</select>
</td>
</tr>

<tr>
<td><font face="calibri">Purchase Date :</font></td>
 
<td>
<select name="day">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select name="month">
<option value="-1">Month:</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
 
<select name="year">
 
<option value="-1">Year:</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
</select>
</td>
</tr>
 
<tr>
<td colspan="2" align="center">
<input type="submit" value="Purchase" name="sub">
</td>
</tr>
</table>
 
</form>';


} 
 
 }
 }
 else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
 ?>
</body>
</html>