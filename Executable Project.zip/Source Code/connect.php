<?php
$con=mysqli_connect('localhost','u2130105','-p!}BNTB*cTs','u2130105_project');
?>