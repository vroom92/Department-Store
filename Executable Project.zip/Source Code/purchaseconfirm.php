<?php
ob_start();
session_start();
if($_SESSION['login']=="2"||$_SESSION['login']=="1")
{
?>
<head>
<title>Purchase Confirmation</title>
<style>
table {
border-collapse:collapse;
}
table th,td{
border:none;
}
</style>
</head>
<body background="photos/back4_varun.jpg">
<?php
include 'connect.php';
$prod_name=$_POST['proname'];
$qty=$_POST['quantity'];
$price=$_POST['price'];
$day=$_POST['day'];
$month=$_POST['month'];
$year=$_POST['year'];
$submit=$_POST['sub'];
$total=$qty*$price;

//condition to check whether $total is less than cash in hand if yes proceed or else purchase unsuccessfull
$dep=0;
$result=mysqli_query($con,'select * from deposit');
while($row=mysqli_fetch_array($result))
{
$dep=$dep+$row[2];
}
$with=0;
$result1=mysqli_query($con,'select * from withdraw');
while($row1=mysqli_fetch_array($result1))
{
$with=$with+$row1[2];
}
$result3=mysqli_query($con,'select * from current');
while($row3=mysqli_fetch_array($result3))
{
$cur=$row3[0];
}
$cur=$cur-$with+$dep;


if($cur>$total)
{


if($submit=='Purchase')     //if product exists
{
$result=mysqli_query($con,'select * from stock');
while($row=mysqli_fetch_array($result))
{
if($prod_name==$row[1])
{
$q=$row[4]+$qty;
$pr=$row[5]+$total;
mysqli_query($con,"update stock set qty=$q where prod_name='$prod_name'");
mysqli_query($con,"update stock set tot_price=$pr where prod_name='$prod_name'");
$res=mysqli_query($con,"select prod_id from stock where prod_name='$prod_name'");
$row1=mysqli_fetch_array($res);
$prod_id=$row1[0];
}
}
mysqli_query($con,"insert into purchase(prod_name,prod_id,qty,price,tot_price,date) values('$prod_name','$prod_id',$qty,$price,$total,'$year-$month-$day')");
mysqli_query($con,"insert into withdraw(dom,balance) values('$year-$month-$day',$total)");
//withdraw entry
echo '<center>
<br><br><img src="photos/image_logo.jpe" width="150">
<h3><font face="calibri" color="slateblue"><b><u>Purchase Confirmation</font></h3><center>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Product Id :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$prod_id.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Product Name:</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$prod_name.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Quantity :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$qty.'</font></td>
</tr>
 

<tr>
<td><font face="calibri">Total Price :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$total.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Updated Quantity :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$q.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Updated Total Price :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$pr.'</font></td>
</tr>
 

<tr>
<td><font face="calibri">Date :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$year.'-'.$month.'-'.$day.'</font>
</td>
</tr></table>

<br><h2>Successfully Done!<br> Now Go To</h2><table border="0">
<tr>
<td><a href="home.php"><font color="blue" size="3">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="purchase.php?sub=addnew"><font color="blue" size="3">Add New Product</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="purchase.php?sub=purpro"><font color="blue" size="3">Product Purchase</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="blue" size="3">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
</center>';
}
else if($submit=='Add_Product')  //if product does not exist
{
$code=uniqid();
$c=substr($code,-8);
mysqli_query($con,"insert into stock(prod_name,prod_id,price,qty,tot_price) values('$prod_name','$c',$price,$qty,$total)");
mysqli_query($con,"insert into purchase(prod_name,prod_id,qty,price,tot_price,date) values('$prod_name','$c',$qty,$price,$total,'$year-$month-$day')");
mysqli_query($con,"insert into withdraw(dom,balance) values('$year-$month-$day',$total)");
//withdraw entry
echo '<center>
<br><br><img src="photos/image_logo.jpe" width="150">
<h3><font face="calibri" color="slateblue"><b><u>Purchase Confirmation</font></h3><center>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Product Id :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$c.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Product Name:</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$prod_name.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Quantity :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$qty.'</font></td>
</tr>
 

<tr>
<td><font face="calibri">Total Price :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$total.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Updated Quantity :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$qty.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Updated Total Price :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$total.'</font></td>
</tr>
 

<tr>
<td><font face="calibri">Date :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$year.'-'.$month.'-'.$day.'</font>
</td>
</tr></table>

<br><h2>Successfully Done!<br> Now Go To</h2><table border="0">
<tr>
<td><a href="home.php"><font color="blue" size="3">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="purchase.php?sub=addnew"><font color="blue" size="3">Add New Product</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="purchase.php?sub=purpro"><font color="blue" size="3">Product Purchase</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="blue" size="3">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
</center>';

}
}
else
{
 ?>
<script type="text/javascript">
alert("Not Enough Balance in Current Account!");
location="purchase.php";
</script><?php
}

}
 else
{
 ?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>
</body>
</html>
