<?php
$con=mysqli_connect('localhost','root','vroom','project');
?>