<?php
ob_start();
session_start();
if($_SESSION['login']=="4"||$_SESSION['login']=="1")
{
?>
<head>
<title>Sale Confirmation</title>
<style>
table {
border-collapse:collapse;
}
table th,td{
border:none;
}
</style>
</head>
<body background="photos/back4_varun.jpg">
<?php
include 'connect.php';
$prod_name=$_POST['proname'];
$qty=$_POST['qty'];
$day=$_POST['day'];
$month=$_POST['month'];
$year=$_POST['year'];
$submit=$_POST['sub'];
$custname=$_POST['custname'];
$code=$_POST['code'];

$res=mysqli_query($con,"select qty from stock where prod_name='$prod_name'");
$rows1=mysqli_fetch_array($res);
if($rows1[0]>=$qty)
{
$newqty=$rows1[0]-$qty;
$res1=mysqli_query($con,"select price from stock where prod_name='$prod_name'");
$rows2=mysqli_fetch_array($res1);
$price=$rows2[0];
$tot=$newqty*$price;
$early=$price*$qty;
$price1=0.1*$price;
$price2=$price+$price1;
$total=$price2*$qty;
$dis=$total*0.15;
$tax=$total*0.125;
$pay=$total-$dis+$tax;
$income=$pay-$early;
mysqli_query($con,"update stock set qty=$newqty where prod_name='$prod_name'");
mysqli_query($con,"update stock set tot_price=$tot where prod_name='$prod_name'");
mysqli_query($con,"insert into sale(cust_name,cust_id,qty,price,tot_price,date,income) values('$custname','$code',$qty,$price2,$total,'$year-$month-$day',$income)");
mysqli_query($con,"insert into deposit(dom,balance) values('$year-$month-$day',$pay)");

echo '<center>
<br><br><img src="photos/image_logo.jpe" width="150">
<h3><font face="calibri" color="slateblue"><b><u>Sale Confirmation</font></h3><center>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Id :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$code.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Customer Name:</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$custname.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Quantity of '.$prod_name.' :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$qty.'</font></td>
</tr>
 

<tr>
<td><font face="calibri">Total Price :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$pay.'</font>
</td>
</tr>
  
<tr>
<td><font face="calibri">Date :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$year.'-'.$month.'-'.$day.'</font>
</td>
</tr></table>

<br><h2>'.$qty.' '.$prod_name.' Sold Successfully!<br> Now Go To</h2><table border="0">
<tr>
<td><a href="home.php"><font color="blue" size="3">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="getbill.php?day='.$day.'&month='.$month.'&year='.$year.'&cust_id='.$code.'&prod_name='.$prod_name.'"><font color="blue" size="3">Get Bill</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="blue" size="3">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="blue" size="3">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
</center>';
}
else
{?>
<script type="text/javascript">
alert("Selling Quantity is more than Stock!");
location="sale.php";
</script><?php
}
}

else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>
</body>
</html>

