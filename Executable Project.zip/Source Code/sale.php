<?php
ob_start();
session_start();
if($_SESSION['login']=="4"||$_SESSION['login']=="1")
{
?>
<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"/>
<title>Sales Panel</title>
<script type="text/javascript">
function validate()
{
var x=document.forms["register"]["custname"].value;
//document.write(x);
var y=document.forms["register"]["phone"].value;
var z=document.forms["register"]["email"].value;
var atpos=z.indexOf("@");
var dotpos=z.lastIndexOf(".");
if(x==null||x=="")
{alert("Customer name cannot blank!");
return false;
}
else if(y==null||y=="")
{alert("Phone number cannot be blank!");
return false;
}
else if(!y.match(/^\d+/))
{alert("Only numeric characters allowed for phone no");
return false;
}
else if (y.length>10||y.length<10)
{
alert("Phone no should contain 10 digits");
return false;
}
else if(z==null||z=="")
{alert("Email cannot be blank!");
return false;
}
else if(atpos<1||dotpos<atpos+2||dotpos+2>=z.length)
{
alert("Not a valid email address");
return false;
}
else
{
return true;
}
}
</script>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Sales Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<?php 
include 'connect.php';
if(!isset($_GET['sub']))
{
echo '<br><table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
<tr>
<td><font face="calibri">1:</font></td>
<td><a href="sale.php?sub=regcus">Register Customer</a></td>
<td><img src="photos/regcus.jpe" width="65"></td>
</tr>
 

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="sale.php?sub=dlycus">Daily Customer</a></td>
<td><img src="photos/dailycus.jpe" width="50"></td>
</tr>

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="manage.php">Manage Customer</a></td>
<td><img src="photos/manage.jpe" width="50"></td>
</tr>
 </table>';
 
 }
 else
 {
 $submit=$_GET['sub'];
 if($submit=='regcus')
 {
echo '<form action="sale2.php" method="post" name="register" onSubmit="return validate();">
 <h3>Register New Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Name :</font></td>
<td><input type="text" name="custname" maxlength="30"/><font face="calibri">
(maximum 30 characters)</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Address :</font></td>
<td><input type="text" name="address"/>
</td>
</tr>
 
<tr>
<td><font face="calibri">Phone :</font></td>
<td><input type="text" name="phone"/><font face="calibri">
(in numeric)</font>
</td>
</tr>

<tr>
<td><font face="calibri">Email :</font></td>
<td><input type="text" name="email"/>
</td>
</tr>
 
<tr>
<td colspan="2" align="center">
<input type="submit" value="Register" name="sub">
</td>
</tr>
</table>
 
</form>';
}
else if($submit=='dlycus')
{
echo '
<form action="sale2.php" method="post" name="search">
 <h3>Search Existing Customer</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Customer Id :</font></td>
<td><input type="text" name="cid" maxlength="30"/>
</td>
</tr>
<tr>
<td colspan="2" align="center">
<input type="submit" value="Search" name="sub">
</td>
</tr>
</table>
 </form>';
} 
}
 }
 else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
 ?>
</body>
</html>