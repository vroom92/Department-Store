<html>
<head>
<style>
table {
border-collapse:collapse;
}
table th,td{
border:none;
}
</style>
<script type="text/javascript">
function validate()
{
var x=document.forms["login"]["user"].value;
//document.write(x);
var y=document.forms["login"]["password"].value;
if(x==null||x=="")
{alert("Username cannot blank!");
return false;
}
else if(y==null||y=="")
{alert("Password cannot be blank!");
return false;
}
else
{
return true;
}
}
</script>
<title>Varun Enterprises</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/banner_varun.jpg" width="1250" height="150"><br><br>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises</h1>
<hr>
<table border="0">
<tr>
<td><a href="login.php"><font color="black" size="5">Login</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<br>
<form action="login1.php" method="post" name="login" onSubmit="return validate();">
 
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">UserName :</font></td>
<td><input type="text" name="user" maxlength="30"/><font face="calibri">
(created during Registration)</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Password :</font></td>
<td><input type="password" name="password"/>
</td>
</tr>
 
<tr>
<td colspan="2" align="center">
<input type="submit" value="Submit" name="sub">
</td>
</tr>
</table>
 
</form>
</body>
</html>