<?php
ob_start();
session_start();
if($_SESSION['login']=="3"||$_SESSION['login']=="1")
{
?>
<html>
<head>
<link href="style.css" rel="stylesheet" type="text/css"/>
<title>Accounts Panel</title>
<script type="text/javascript">
function validate()
{
var x=document.forms["deposit"]["dep"].value;
var y=document.forms["withdraw"]["with"].value;
if(x==null||x=="")
{alert("Amount name cannot blank!");
return false;
}
else if(!x.match(/^\d+/))
{alert("Only numeric characters allowed for amount!");
return false;
}
else if(y==null||y=="")
{alert("Amount name cannot blank!");
return false;
}
else if(!y.match(/^\d+/))
{alert("Only numeric characters allowed for amount!");
return false;
}
else
{
return true;
}
}
</script>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Accounts Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="accounts.php"><font color="black" size="5">Accounts</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<?php 
include 'connect.php';
if(!isset($_GET['sub']))
{
echo '<br><table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
<tr>
<td><font face="calibri">1:</font></td>
<td><a href="accounts.php?sub=trans">Transaction</a></td>
<td><img src="photos/trans.jpg" width="50"></td>
</tr>
 

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="accounts.php?sub=viewrec">View Records</a></td>
<td><img src="photos/record.jpe" width="50"></td>
</tr>
</table>';
 }
 else
 {
  $submit=$_GET['sub'];
  
 
 if($submit=='trans')
 {
 echo '<br><table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
<tr>
<td><font face="calibri">1:</font></td>
<td><a href="accounts.php?sub=deposit">Deposit Money</a></td>
<td><img src="photos/deposit.jpe" width="65"></td>
</tr>
 

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="accounts.php?sub=withdraw">Withdraw Money</a></td>
<td><img src="photos/withdraw.jpg" width="65"></td>
</tr>
<tr>
<td><font face="calibri">2:</font></td>
<td><a href="curacc.php">Current Account Status</a></td>
<td><img src="photos/curac.jpe" width="65"></td>
</tr>
</table>
<center><br><a href="accounts.php">Go Back</a></center>';
 
 }
 else if($submit=='viewrec')
 {
 echo '<br><table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
<tr>
<td><font face="calibri">1:</font></td>
<td><a href="purchaserec.php">Purchase Records</a></td>
<td><img src="photos/pur.jpe" width="65"></td>
</tr>
 

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="salesrec.php">Sales Records</a></td>
<td><img src="photos/sale.jpg" width="50"></td>
</tr>
<tr>
<td><font face="calibri">2:</font></td>
<td><a href="accounts.php?sub=accrec">Account Records</a></td>
<td><img src="photos/acc.jpe" width="50"></td>
</tr>
</table><center><br><a href="accounts.php">Go Back</a></center>';
 
 }
  else if($submit=='accrec')
 {
 echo '<br><table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
<tr>
<td><font face="calibri">1:</font></td>
<td><a href="depositrec.php">Deposit Records</a></td>
<td><img src="photos/deposit.jpe" width="65"></td>
</tr>
 

<tr>
<td><font face="calibri">2:</font></td>
<td><a href="withdrawrec.php">Withdraw Records</a></td>
<td><img src="photos/withdraw.jpg" width="50"></td>
</tr>
</table><center><br><a href="accounts.php?sub=viewrec">Go Back</a></center>';
 
 }
 else if($submit=='deposit')
 {
  $dep=0;
$result=mysqli_query($con,'select * from deposit');
while($row=mysqli_fetch_array($result))
{
$dep=$dep+$row[2];
}
$with=0;
$result1=mysqli_query($con,'select * from withdraw');
while($row1=mysqli_fetch_array($result1))
{
$with=$with+$row1[2];
}
$result3=mysqli_query($con,'select * from current');
while($row3=mysqli_fetch_array($result3))
{
$cur=$row3[0];
}
$cur=$cur-$with+$dep;

 echo '<form action="accounts.php" method="get" name="deposit" onSubmit="return validate();">
 <h3>Deposit Money</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 
<tr>
<td><font face="calibri">Current Balance :</font></td>
<td> Rs. '.$cur.'/-
</td>
</tr>
 
 
<tr>
<td><font face="calibri">Enter Deposit Amount :</font></td>
<td><input type="text" name="dep"/>
</td>
</tr>
 
 <tr>
<td><font face="calibri">Deposit Date :</font></td>
 
<td>
<select name="day">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select name="month">
<option value="-1">Month:</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
 
<select name="year">
 
<option value="-1">Year:</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
</select>
</td>
</tr>

<tr>
<td colspan="2" align="center">
<input type="submit" value="ConfirmDeposit" name="sub">
</td>
</tr>
</table>
 
</form>';
 
 }
 else if($submit=='ConfirmDeposit')
 {
 $dep1=$_GET['dep'];
 $day=$_GET['day'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 mysqli_query($con,"insert into deposit(dom,balance) values('$year-$month-$day',$dep1)");
   $dep=0;
$result=mysqli_query($con,'select * from deposit');
while($row=mysqli_fetch_array($result))
{
$dep=$dep+$row[2];
}
$with=0;
$result1=mysqli_query($con,'select * from withdraw');
while($row1=mysqli_fetch_array($result1))
{
$with=$with+$row1[2];
}
$result3=mysqli_query($con,'select * from current');
while($row3=mysqli_fetch_array($result3))
{
$cur=$row3[0];
}
$cur=$cur-$with+$dep;


echo '<br><h2>Confirmation!<br>Current Balance Rs. '.$cur.'/-<br> Rs. '.$dep1.' has been added to your account.</h2>

<center><a href="accounts.php?sub=trans"><font color="blue" size="3">Go Back</font></a>
</center>';

}
else if($submit=='withdraw')
 {
  $dep=0;
$result=mysqli_query($con,'select * from deposit');
while($row=mysqli_fetch_array($result))
{
$dep=$dep+$row[2];
}
$with=0;
$result1=mysqli_query($con,'select * from withdraw');
while($row1=mysqli_fetch_array($result1))
{
$with=$with+$row1[2];
}
$result3=mysqli_query($con,'select * from current');
while($row3=mysqli_fetch_array($result3))
{
$cur=$row3[0];
}
$cur=$cur-$with+$dep;

 echo '<form action="accounts.php" method="get" name="withdraw" onSubmit="return validate();">
 <h3>Withdraw Money</h3>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 
<tr>
<td><font face="calibri">Current Balance :</font></td>
<td> Rs. '.$cur.'/-
</td>
</tr>
 
 
<tr>
<td><font face="calibri">Enter Withdraw Amount :</font></td>
<td><input type="text" name="with"/>
</td>
</tr>
 
 <tr>
<td><font face="calibri">Withdraw Date :</font></td>
 
<td>
<select name="day">
<option value="-1">Day:</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
 
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
 
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
 
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
 
<option value="31">31</option>
</select>
 
<select name="month">
<option value="-1">Month:</option>
<option value="01">Jan</option>
<option value="02">Feb</option>
<option value="03">Mar</option>
<option value="04">Apr</option>
<option value="05">May</option>
<option value="06">Jun</option>
<option value="07">Jul</option>
<option value="08">Aug</option>
<option value="09">Sep</option>
<option value="10">Oct</option>
<option value="11">Nov</option>
<option value="12">Dec</option>
</select>
 
<select name="year">
 
<option value="-1">Year:</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
</select>
</td>
</tr>

<tr>
<td colspan="2" align="center">
<input type="submit" value="ConfirmWithdraw" name="sub">
</td>
</tr>
</table>
 
</form>';
 
 }
 else if($submit=='ConfirmWithdraw')
 {
 $dep1=$_GET['with'];
 $day=$_GET['day'];
 $month=$_GET['month'];
 $year=$_GET['year'];
 mysqli_query($con,"insert into withdraw(dom,balance) values('$year-$month-$day',$dep1)");
   $dep=0;
$result=mysqli_query($con,'select * from deposit');
while($row=mysqli_fetch_array($result))
{
$dep=$dep+$row[2];
}
$with=0;
$result1=mysqli_query($con,'select * from withdraw');
while($row1=mysqli_fetch_array($result1))
{
$with=$with+$row1[2];
}
$result3=mysqli_query($con,'select * from current');
while($row3=mysqli_fetch_array($result3))
{
$cur=$row3[0];
}
$cur=$cur-$with+$dep;


echo '<br><h2>Confirmation!<br>Current Balance Rs. '.$cur.'/-<br> Rs. '.$dep1.' has been deducted to your account.</h2>

<center><a href="accounts.php?sub=trans"><font color="blue" size="3">Go Back</font></a>
</center>';

}
 
 }
 }
 else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>
</body>
</html>