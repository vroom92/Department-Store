<?php
ob_start();
session_start();
if($_SESSION['login']=="4"||$_SESSION['login']=="1")
{
?>
<head>
<title>Get Bill</title>
<style>
table {
border-collapse:collapse;
}
table th,td{
border:none;
}
</style>
</head>
<body background="photos/back4_varun.jpg">
<?php
include 'connect.php';
$day=$_GET['day'];
$month=$_GET['month'];
$year=$_GET['year'];
$cust_id=$_GET['cust_id'];
$prod_name=$_GET['prod_name'];
$code=uniqid();
$bill=substr($code,-4);

$result1=mysqli_query($con,"select * from customer where cust_id='$cust_id'");
while($row1=mysqli_fetch_array($result1))
{
$phone=$row1[4];
$address=$row1[3];
}

$result=mysqli_query($con,"select * from sale where date='$year-$month-$day' and cust_id='$cust_id'");
while($row=mysqli_fetch_array($result))
{
$custname=$row[1];
$qty=$row[3];
$total=$row[5];

}
$dis=$total*0.15;
$tax=$total*0.125;
$pay=$total-$dis+$tax;

echo '<center>
<br><br><img src="photos/image_logo.jpe" width="150">
<h3><font face="calibri" color="slateblue"><b><u>Sale Confirmation</font></h3><center>
<table align="center" cellpadding = "10" bgcolor="Slateblue" border="1">
 

<tr>
<td><font face="calibri">Bill Id :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$bill.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Customer Name:</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$custname.'</font>
</td>
</tr>
<tr>
<td><font face="calibri">Phone :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$phone.'</font>
</td>
</tr>
<tr>
<td><font face="calibri">Address :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$address.'</font>
</td>
</tr>
 

<tr>
<td><font face="calibri">Quantity of '.$prod_name.' :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$qty.'</font></td>
</tr>
 

<tr>
<td><font face="calibri">Total Price :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$total.'</font>
</td>
</tr>
<tr>
<td><font face="calibri">Discount 15% :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$dis.'</font>
</td>
</tr>

<tr>
<td><font face="calibri">Tax 12.5% :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$tax.'</font>
</td>
</tr>

<tr>
<td><font face="calibri">Grant Total :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$pay.'</font>
</td>
</tr>
  
<tr>
<td><font face="calibri">Date :</font></td>
<td><font face="calibri" color="black" size="4"><b>'.$year.'-'.$month.'-'.$day.'</font>
</td>
</tr></table>

<br><h2>'.$qty.' '.$prod_name.' Sold Successfully!<br> Now Go To</h2><table border="0">
<tr>
<td><a href="home.php"><font color="blue" size="3">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="javascript:window.print()"><font color="blue" size="3">Print Bill</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="blue" size="3">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="blue" size="3">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
</center>';
}
else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>
</body>
</html>
