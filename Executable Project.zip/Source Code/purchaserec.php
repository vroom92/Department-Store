<?php
ob_start();
session_start();
include 'connect.php';
if($_SESSION['login']=="1"||$_SESSION['login']=="3")
{
echo '<html>
<head>
<title>
Purchase Records</title>
<style type="text/css">
table {
	background-color: #f5f5f5;
	padding: 5px;
	border-radius: 5px;
	
	border: 1px solid #ebebeb;
}
table td, table th {
	padding: 1px 5px;
}
table thead {
	font: normal 15px Helvetica Neue,Helvetica,sans-serif;
	text-shadow: 0 1px 0 white;
	color: #999;
}
table th {
	text-align: left;
	border-bottom: 1px solid #fff;
}
table td {
	font-size: 14px;
}
table td:hover {
	background-color: #fff;
}
</style>
</head>
<body background="photos/back2_varun.jpg">
<center>
<br><br><img src="photos/image_logo.jpe" width="150">
<br><br>
<span style="background-color:#01A9DB;color:white; width">&nbsp;&nbsp;&nbsp;<font size="4">
<b>Purchase Records&nbsp;&nbsp;&nbsp;</font></span><br><br>
<center>
<hr width="400"></center>
<center><table border="0">
<tr>
<th><font size="4"><u>Sl No.</font></th>
<th><font size="4"><u>Product Name</font></th>
<th><font size="4"><u>Product ID</font></th>
<th><font size="4"><u>Quantity</font></th>
<th><font size="4"><u>Price</font></th>
<th><font size="4"><u>Total Price</font></th>
<th><font size="4"><u>Date</font></th>

</tr>';
$result=mysqli_query($con,'select * from purchase');
while($row=mysqli_fetch_array($result))
{
echo '<tr><td align="center"><font size="4">'.$row[0].'</font></td>
<td align="center"><font size="4">'.$row[1].'</font></td>
<td align="center"><font size="4">'.$row[2].'</font></td>
<td align="center"><font size="4">'.$row[3].'</font></td>
<td align="center"><font size="4">'.$row[4].'</font></td>
<td align="center"><font size="4">'.$row[5].'</font></td>
<td align="center"><font size="4">'.$row[6].'</font></td>

</tr>';
}

echo '</table>
<center><hr width="400"></center>
<table border="0">
<tr>
<td><a href="home.php"><font color="blue" size="3">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="accounts.php"><font color="blue" size="3">Accounts</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="blue" size="3">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<center>';

}
else
 {?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>
</body>
</html>

