<html>
<head>
<title>Admins Panel</title>
</head>
<?php
if(!isset($_POST['sub']))
{
echo '
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Admins Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="purchase.php"><font color="black" size="5">Purchase</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="stock.php"><font color="black" size="5">Stock</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="accounts.php"><font color="black" size="5">Accounts</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="customers.php"><font color="black" size="5">Customers</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
<center><h2>Upload Ur Pic</h2><br>
<form name="jlt" action="test.php" method="post" 
enctype="multipart/form-data">
First Name<input type="text" name="name" size="40"><br>
Photo<input type="file" name="file"><br>
<input type="submit" name="sub" value="submit">
</form><hr>
</body>
</html>';
}
else
{
echo '
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Admins Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="home.php"><font color="black" size="5">Home</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="purchase.php"><font color="black" size="5">Purchase</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="stock.php"><font color="black" size="5">Stock</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="accounts.php"><font color="black" size="5">Accounts</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="customers.php"><font color="black" size="5">Customers</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr><center><h2>Ur Pic</h2><br>';
$name=$_POST['name'];
$allowedExts = array("jpg", "jpeg", "gif", "png","JPG","PNG","GIF");
$extension = end(explode(".", $_FILES["file"]["name"]));
//echo $name;
//echo $extension;
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/JPG")
|| ($_FILES["file"]["type"] == "image/PNG")
|| ($_FILES["file"]["type"] == "image/GIF")
|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 6000000)
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
	$photo=$name.".".$extension;
    if (file_exists("photos/" . $photo))
      {
	  
	  echo $photo. " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"], "photos/".$photo);
	  echo '<img src="photos/'.$photo.'" width="300">';
	  echo '<br><a href="test.php">Change the pic</a>';
      }
    }
  }
else
  {
  echo "Invalid photo file";
  }

}
?>