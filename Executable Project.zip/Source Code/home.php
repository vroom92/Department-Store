<?php
ob_start();
session_start();?>
<?php 
if($_SESSION['login']=="1")
{
echo
'<html>
<head>
<title>Admins Panel</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Admins Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="purchase.php"><font color="black" size="5">Purchase</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="stock.php"><font color="black" size="5">Stock</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="accounts.php"><font color="black" size="5">Accounts</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="customerrec.php"><font color="black" size="5">Customers</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
</body>
</html>';
}
else if($_SESSION['login']=="2")
{
echo
'<html>
<head>
<title>Purchasers Panel</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Purchasers Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="purchase.php"><font color="black" size="5">Purchase</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
</body>
</html>';
}
else if($_SESSION['login']=="3")
{
echo
'<html>
<head>
<title>Accounts Panel</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Accounts Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="accounts.php"><font color="black" size="5">Accounts</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
</body>
</html>';
}
else if($_SESSION['login']=="4")
{
echo
'<html>
<head>
<title>Sales Panel</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Sales Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="sale.php"><font color="black" size="5">Sale</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
</body>
</html>';
}
else if($_SESSION['login']=="5")
{
echo
'<html>
<head>
<title>Stock Panel</title>
</head>
<body background="photos/back1_varun.jpg" text="white">
<center>
<img src="photos/image_logo.jpe" width="150">
<h1>Varun Enterprises Stock Panel</h1>
<h3>Choose any option from the below panel</h3>
<hr>
<table border="0">
<tr>
<td><a href="stock.php"><font color="black" size="5">Stock</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</td>
<td><a href="logout.php"><font color="black" size="5">Logout</font></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
</tr>
</table>
<hr>
</body>
</html>';
}
else
{?>
<script type="text/javascript">
alert("Login first!");
</script><?php
include("login.php");
//header("location:login.php");
}
?>