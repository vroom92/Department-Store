<?php
ob_start();
session_start();
include 'connect.php';
$user=$_POST['user'];
$password=$_POST['password'];


$result=mysqli_query($con,"select * from login where user='$user' and pass='$password'");
if($result)
{
$rows=mysqli_num_rows($result);
if($rows>0)
{
$res=mysqli_query($con,"select role from login where user='$user'");
$rows1=mysqli_fetch_array($res);
if($rows1[0]==1)
{
$code=uniqid();
mysqli_query($con,"update login set code='$code' where user='$user'");
$res2=mysqli_query($con,"select email from login where user='$user'");
$rows2=mysqli_fetch_array($res2);
$to=$rows2[0];
$subject='Admin Confirmation';
$from="varun@u2130105.nettech.net.in";
$message='Dear user '.$to.' Paste the code '.$code.' in the page that you have been redirected to & fill your username to login as admin.'; 

//http://u2130105.nettech.net.in/assignments/Project/confirm.php?user='.$user.'&code='.$code;


$headers="From:" .$from;
mail($to,$subject,$message,$headers);?>
<script type="text/javascript">
alert("An email has been sent to you.. Kindly Confirm.");
location="confirm.php";
</script>
<?php
include("login.php");
}
else if($rows1[0]==2)
{
$_SESSION['login']="2";
header("location:home.php");
}
else if($rows1[0]==3)
{
$_SESSION['login']="3";
header("location:home.php");
}
else if($rows1[0]==4)
{
$_SESSION['login']="4";
header("location:home.php");
}
else if($rows1[0]==5)
{
$_SESSION['login']="5";
header("location:home.php");
}
}
else
{?>
<script type="text/javascript">
alert("Invalid Login");
</script><?php
include("login.php");
//header("location:login.php");
}
}
?>